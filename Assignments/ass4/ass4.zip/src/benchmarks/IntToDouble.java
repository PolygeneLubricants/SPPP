package benchmarks;

public interface IntToDouble {
  double call(int i);
}
